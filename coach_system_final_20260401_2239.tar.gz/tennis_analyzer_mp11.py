#!/usr/bin/env python3
"""
网球发球分析器 1.1
在原始 mp10 版本基础上，增加：
- 输入质量检查
- 发球阶段切分
- 分阶段特征提取
- 分项评分与问题证据
- 更稳定的 JSON 输出

说明：
1. 这是兼容你现有链路的“低风险升级版”，仍以 MediaPipe Pose 为主。
2. 先不引入大视觉模型和完整等级分类器，但预留 level_estimate 字段。
3. 先假设用户是右手发球；后续可再加入左右手自动识别。
"""
from __future__ import annotations

import json
import math
import os
import sqlite3
import sys
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from statistics import median
from typing import Dict, List, Optional

import cv2
import mediapipe as mp
import numpy as np
from mediapipe.tasks.python import vision
from mediapipe.tasks.python.core.base_options import BaseOptions

DB_PATH = os.getenv("DB_PATH", "/data/db/xiaolongxia_learning.db")
MODEL_PATH = os.getenv("POSE_MODEL_PATH", "pose_landmarker_lite.task")
DEFAULT_FRAME_STEP = int(os.getenv("POSE_FRAME_STEP", "3"))
RIGHT_HANDED = True


@dataclass
class FramePose:
    frame: int
    timestamp: float
    body_scale: float
    shoulder_width: float
    shoulder_center_x: float
    shoulder_center_y: float
    hip_center_x: float
    hip_center_y: float
    left_wrist_x: float
    left_wrist_y: float
    right_wrist_x: float
    right_wrist_y: float
    right_elbow_angle: float
    right_knee_angle: float
    shoulder_tilt_deg: float
    right_arm_extension: float
    left_arm_extension: float


# ---------- 基础工具 ----------

def get_db_connection() -> sqlite3.Connection:
    return sqlite3.connect(DB_PATH)


def load_serve_rules() -> List[Dict]:
    """保留对现有 serve_rules 的兼容读取。"""
    print("📚 加载杨超教练规则...")
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM serve_rules WHERE enabled = 1 ORDER BY priority")
        rules = [dict(row) for row in cursor.fetchall()]
        conn.close()
        print(f"✅ 已加载 {len(rules)} 条规则")
        return rules
    except Exception as exc:
        print(f"⚠️ 读取 serve_rules 失败：{exc}")
        return []


def load_coach_knowledge(phase: str, knowledge_type: str = None, limit: int = 3) -> List[Dict]:
    """从统一知识库加载教练知识点
    
    Args:
        phase: 阶段 (ready, toss, loading, contact, follow)
        knowledge_type: 知识类型 (key_point, common_error, correction)
        limit: 返回的最大数量
    
    Returns:
        知识点列表
    """
    try:
        conn = get_db_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        if knowledge_type:
            cursor.execute('''
                SELECT coach_name, title, summary, key_elements, common_errors, 
                       correction_method, knowledge_type, confidence
                FROM coach_knowledge_unified 
                WHERE knowledge_class = ? AND knowledge_type = ?
                ORDER BY confidence DESC, quality_grade DESC
                LIMIT ?
            ''', (phase, knowledge_type, limit))
        else:
            cursor.execute('''
                SELECT coach_name, title, summary, key_elements, common_errors, 
                       correction_method, knowledge_type, confidence
                FROM coach_knowledge_unified 
                WHERE knowledge_class = ?
                ORDER BY confidence DESC, quality_grade DESC
                LIMIT ?
            ''', (phase, limit))
        
        knowledge_items = [dict(row) for row in cursor.fetchall()]
        conn.close()
        return knowledge_items
    except Exception as exc:
        print(f"⚠️ 读取知识库失败：{exc}")
        return []


def recall_knowledge_for_issues(phase: str, issues: List[str], limit: int = 3) -> List[Dict]:
    """根据问题召回相关教练知识点
    
    Args:
        phase: 阶段
        issues: 问题列表
        limit: 返回的最大数量
    
    Returns:
        匹配的知识点列表
    """
    knowledge_items = []
    
    # 加载该阶段的所有知识点
    all_knowledge = load_coach_knowledge(phase, limit=20)
    
    for item in all_knowledge:
        # 检查是否与问题匹配
        summary = item.get('summary', '')
        title = item.get('title', '')
        
        for issue in issues:
            # 简单匹配：如果问题关键词出现在知识点中
            if issue.lower() in summary.lower() or issue.lower() in title.lower():
                knowledge_items.append(item)
                break
    
    # 去重并限制数量
    seen = set()
    unique_items = []
    for item in knowledge_items:
        key = item.get('title', '')
        if key not in seen:
            seen.add(key)
            unique_items.append(item)
            if len(unique_items) >= limit:
                break
    
    return unique_items


def calculate_angle(a, b, c) -> float:
    a = np.array(a)
    b = np.array(b)
    c = np.array(c)
    radians = np.arctan2(c[1] - b[1], c[0] - b[0]) - np.arctan2(a[1] - b[1], a[0] - b[0])
    angle = np.abs(radians * 180.0 / np.pi)
    if angle > 180.0:
        angle = 360.0 - angle
    return float(angle)


def calculate_distance(a, b) -> float:
    a = np.array(a)
    b = np.array(b)
    return float(np.linalg.norm(a - b))


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def safe_mean(values: List[float], default: float = 0.0) -> float:
    return float(sum(values) / len(values)) if values else default


def make_pose_detector() -> vision.PoseLandmarker:
    model_path = Path(MODEL_PATH)
    if not model_path.exists():
        raise FileNotFoundError(
            f"未找到姿态模型文件：{MODEL_PATH}。请把 pose_landmarker_lite.task 放到脚本目录，"
            "或通过 POSE_MODEL_PATH 指向正确路径。"
        )

    options = vision.PoseLandmarkerOptions(
        base_options=BaseOptions(model_asset_path=str(model_path)),
        running_mode=vision.RunningMode.VIDEO,
        num_poses=1,
        min_pose_detection_confidence=0.5,
        min_pose_presence_confidence=0.5,
        min_tracking_confidence=0.5,
    )
    return vision.PoseLandmarker.create_from_options(options)


# ---------- 1. 输入检查 + 姿态提取 ----------

def extract_pose_sequence(video_path: str, frame_step: int = DEFAULT_FRAME_STEP) -> Dict:
    print(f"\n🎾 使用 MediaPipe {mp.__version__} 分析视频")
    print(f"📄 文件: {video_path}")

    path = Path(video_path)
    if not path.exists():
        raise FileNotFoundError(f"视频文件不存在：{video_path}")

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise RuntimeError("无法打开视频")

    fps = cap.get(cv2.CAP_PROP_FPS) or 0.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
    duration_sec = (total_frames / fps) if fps > 0 else 0.0

    metadata = {
        "fps": float(fps),
        "total_frames": total_frames,
        "width": width,
        "height": height,
        "duration_sec": round(duration_sec, 3),
        "frame_step": frame_step,
    }

    sampled_frames = 0
    pose_frames: List[FramePose] = []

    with make_pose_detector() as detector:
        frame_index = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            frame_index += 1
            if frame_index % frame_step != 0:
                continue

            sampled_frames += 1
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
            timestamp_ms = int((frame_index / fps) * 1000) if fps > 0 else 0
            result = detector.detect_for_video(mp_image, timestamp_ms)
            if not result.pose_landmarks:
                continue

            lm = result.pose_landmarks[0]
            left_shoulder = lm[11]
            right_shoulder = lm[12]
            right_elbow = lm[14]
            right_wrist = lm[16]
            left_wrist = lm[15]
            left_hip = lm[23]
            right_hip = lm[24]
            right_knee = lm[26]
            right_ankle = lm[28]
            left_ankle = lm[27]
            nose = lm[0]

            body_scale = max(0.08, ((left_ankle.y + right_ankle.y) / 2.0) - nose.y)
            shoulder_width = calculate_distance(
                (left_shoulder.x, left_shoulder.y),
                (right_shoulder.x, right_shoulder.y),
            )
            shoulder_center_x = (left_shoulder.x + right_shoulder.x) / 2.0
            shoulder_center_y = (left_shoulder.y + right_shoulder.y) / 2.0
            hip_center_x = (left_hip.x + right_hip.x) / 2.0
            hip_center_y = (left_hip.y + right_hip.y) / 2.0

            right_elbow_angle = calculate_angle(
                (right_shoulder.x, right_shoulder.y),
                (right_elbow.x, right_elbow.y),
                (right_wrist.x, right_wrist.y),
            )
            right_knee_angle = calculate_angle(
                (right_hip.x, right_hip.y),
                (right_knee.x, right_knee.y),
                (right_ankle.x, right_ankle.y),
            )
            shoulder_tilt_deg = math.degrees(
                math.atan2(right_shoulder.y - left_shoulder.y, right_shoulder.x - left_shoulder.x)
            )
            right_arm_extension = calculate_distance(
                (right_shoulder.x, right_shoulder.y),
                (right_wrist.x, right_wrist.y),
            ) / body_scale
            left_arm_extension = calculate_distance(
                (left_shoulder.x, left_shoulder.y),
                (left_wrist.x, left_wrist.y),
            ) / body_scale

            pose_frames.append(
                FramePose(
                    frame=frame_index,
                    timestamp=round(timestamp_ms / 1000.0, 3),
                    body_scale=body_scale,
                    shoulder_width=shoulder_width,
                    shoulder_center_x=shoulder_center_x,
                    shoulder_center_y=shoulder_center_y,
                    hip_center_x=hip_center_x,
                    hip_center_y=hip_center_y,
                    left_wrist_x=left_wrist.x,
                    left_wrist_y=left_wrist.y,
                    right_wrist_x=right_wrist.x,
                    right_wrist_y=right_wrist.y,
                    right_elbow_angle=right_elbow_angle,
                    right_knee_angle=right_knee_angle,
                    shoulder_tilt_deg=shoulder_tilt_deg,
                    right_arm_extension=right_arm_extension,
                    left_arm_extension=left_arm_extension,
                )
            )

    cap.release()
    print(f"✅ 总帧数: {total_frames}, 采样帧数: {sampled_frames}, 有效姿态帧: {len(pose_frames)}")

    return {
        "metadata": metadata,
        "sampled_frames": sampled_frames,
        "pose_frames": pose_frames,
    }



def inspect_input(metadata: Dict, pose_frames: List[FramePose]) -> Dict:
    sampled_frames = max(1, metadata["total_frames"] // max(1, metadata["frame_step"]))
    pose_valid_ratio = len(pose_frames) / sampled_frames
    warnings: List[str] = []

    if metadata["duration_sec"] > 20:
        warnings.append("视频时长较长，建议裁剪到单次发球前后 3-8 秒。")
    if metadata["width"] < 480 or metadata["height"] < 480:
        warnings.append("视频分辨率较低，关键点稳定性可能不足。")
    if pose_valid_ratio < 0.35:
        warnings.append("人体姿态有效帧占比偏低，可能存在遮挡、距离过远或光线问题。")

    if pose_frames:
        shoulder_ratios = [p.shoulder_width / max(0.08, p.body_scale) for p in pose_frames]
        shoulder_ratio = median(shoulder_ratios)
        camera_view = "front" if shoulder_ratio >= 0.22 else "side"
        motion_valid_ratio = min(1.0, len(pose_frames) / 20.0)
        person_visible_ratio = min(1.0, max(0.0, median([p.body_scale for p in pose_frames]) / 0.75))
    else:
        camera_view = "unknown"
        motion_valid_ratio = 0.0
        person_visible_ratio = 0.0

    analyzable = len(pose_frames) >= 8 and pose_valid_ratio >= 0.25
    quality_score = clamp(
        (0.55 * pose_valid_ratio) + (0.20 * person_visible_ratio) + (0.25 * motion_valid_ratio),
        0.0,
        1.0,
    )

    if not analyzable:
        warnings.append("当前视频不建议直接用于发球技术分析，请重新上传更清晰、更近、更完整的单次发球视频。")

    return {
        "analyzable": analyzable,
        "score": round(quality_score, 3),
        "camera_view": camera_view,
        "pose_valid_ratio": round(pose_valid_ratio, 3),
        "person_visible_ratio": round(person_visible_ratio, 3),
        "motion_valid_ratio": round(motion_valid_ratio, 3),
        "handedness_assumption": "right",
        "warnings": warnings,
    }


# ---------- 2. 发球阶段切分 ----------

def _nearest_frame(frames: List[FramePose], index: int) -> Optional[FramePose]:
    if not frames:
        return None
    index = max(0, min(index, len(frames) - 1))
    return frames[index]



def segment_serve_phases(frames: List[FramePose]) -> Dict:
    if len(frames) < 8:
        return {
            "ready_start": None,
            "toss_release": None,
            "trophy_pose": None,
            "impact_estimate": None,
            "follow_through_end": None,
            "phase_confidence": 0.0,
        }

    ready_idx = 0
    toss_idx = int(np.argmin([p.left_wrist_y for p in frames])) if RIGHT_HANDED else int(np.argmin([p.right_wrist_y for p in frames]))

    trophy_candidates = frames[toss_idx:max(len(frames), toss_idx + 1)]
    if trophy_candidates:
        local_offset = int(np.argmin([p.right_knee_angle for p in trophy_candidates]))
        trophy_idx = toss_idx + local_offset
    else:
        trophy_idx = min(len(frames) - 1, toss_idx + 1)

    impact_candidates = frames[trophy_idx:]
    if impact_candidates:
        local_offset = int(np.argmin([p.right_wrist_y for p in impact_candidates]))
        impact_idx = trophy_idx + local_offset
    else:
        impact_idx = trophy_idx

    follow_idx = min(len(frames) - 1, impact_idx + max(2, int(len(frames) * 0.1)))

    ready = _nearest_frame(frames, ready_idx)
    toss = _nearest_frame(frames, toss_idx)
    trophy = _nearest_frame(frames, trophy_idx)
    impact = _nearest_frame(frames, impact_idx)
    follow = _nearest_frame(frames, follow_idx)

    confidence_parts = [
        1.0 if toss and trophy and impact else 0.0,
        1.0 if toss_idx <= trophy_idx <= impact_idx else 0.0,
        clamp((len(frames) - 8) / 20.0, 0.0, 1.0),
    ]
    phase_confidence = round(safe_mean(confidence_parts), 3)

    return {
        "ready_start": ready.timestamp if ready else None,
        "toss_release": toss.timestamp if toss else None,
        "trophy_pose": trophy.timestamp if trophy else None,
        "impact_estimate": impact.timestamp if impact else None,
        "follow_through_end": follow.timestamp if follow else None,
        "phase_confidence": phase_confidence,
        "_indices": {
            "ready_start": ready_idx,
            "toss_release": toss_idx,
            "trophy_pose": trophy_idx,
            "impact_estimate": impact_idx,
            "follow_through_end": follow_idx,
        },
    }


# ---------- 3. 特征提取 ----------

def _window(frames: List[FramePose], center_idx: int, radius: int = 2) -> List[FramePose]:
    if not frames:
        return []
    start = max(0, center_idx - radius)
    end = min(len(frames), center_idx + radius + 1)
    return frames[start:end]



def extract_phase_features(frames: List[FramePose], phase_marks: Dict) -> Dict:
    if not frames:
        return {}

    indices = phase_marks.get("_indices", {})
    ready = _nearest_frame(frames, indices.get("ready_start", 0))
    toss = _nearest_frame(frames, indices.get("toss_release", 0))
    trophy = _nearest_frame(frames, indices.get("trophy_pose", 0))
    impact = _nearest_frame(frames, indices.get("impact_estimate", len(frames) - 1))
    follow = _nearest_frame(frames, indices.get("follow_through_end", len(frames) - 1))

    loading_window = _window(frames, indices.get("trophy_pose", 0), radius=3)
    impact_window = _window(frames, indices.get("impact_estimate", len(frames) - 1), radius=2)

    toss_features = {}
    if toss:
        toss_features = {
            "toss_hand_height_ratio": round((toss.hip_center_y - toss.left_wrist_y) / max(0.08, toss.body_scale), 3),
            "toss_lateral_offset": round(abs(toss.left_wrist_x - toss.shoulder_center_x) / max(0.04, toss.shoulder_width), 3),
            "confidence": 0.62,
        }

    loading_features = {}
    if loading_window and ready and trophy:
        min_knee = min(p.right_knee_angle for p in loading_window)
        avg_shoulder_tilt = safe_mean([abs(p.shoulder_tilt_deg) for p in loading_window])
        hip_drop_ratio = (ready.hip_center_y - trophy.hip_center_y) / max(0.08, trophy.body_scale)
        loading_features = {
            "min_knee_angle": round(min_knee, 2),
            "shoulder_tilt": round(avg_shoulder_tilt, 2),
            "hip_drop_ratio": round(hip_drop_ratio, 3),
            "confidence": 0.72,
        }

    contact_features = {}
    if impact_window:
        best_impact = min(impact_window, key=lambda p: p.right_wrist_y)
        avg_extension = safe_mean([p.right_arm_extension for p in impact_window])
        impact_height_ratio = ((best_impact.hip_center_y + best_impact.body_scale * 0.45) - best_impact.right_wrist_y) / max(0.08, best_impact.body_scale)
        contact_features = {
            "impact_arm_extension": round(avg_extension, 3),
            "impact_height_ratio": round(impact_height_ratio, 3),
            "impact_elbow_angle": round(best_impact.right_elbow_angle, 2),
            "confidence": 0.66,
        }

    balance_features = {}
    if impact and follow:
        hip_shift = abs(follow.hip_center_x - impact.hip_center_x) / max(0.08, impact.shoulder_width)
        recovery = clamp(1.0 - hip_shift, 0.0, 1.0)
        balance_features = {
            "recovery_score": round(recovery, 3),
            "hip_shift_ratio": round(hip_shift, 3),
            "confidence": 0.58,
        }

    rhythm_features = {}
    if phase_marks.get("toss_release") and phase_marks.get("trophy_pose") and phase_marks.get("impact_estimate"):
        toss_to_trophy = phase_marks["trophy_pose"] - phase_marks["toss_release"]
        trophy_to_impact = phase_marks["impact_estimate"] - phase_marks["trophy_pose"]
        rhythm_features = {
            "toss_to_trophy_sec": round(toss_to_trophy, 3),
            "trophy_to_impact_sec": round(trophy_to_impact, 3),
            "confidence": 0.55,
        }

    return {
        "toss": toss_features,
        "loading": loading_features,
        "contact": contact_features,
        "balance": balance_features,
        "rhythm": rhythm_features,
    }


# ---------- 4. 诊断与评分 ----------

def _problem(problem_code: str, phase_name: str, severity: str, description: str, advice: str, evidence_ts: Optional[float], confidence: float) -> Dict:
    return {
        "problem_code": problem_code,
        "phase_name": phase_name,
        "severity": severity,
        "description": description,
        "correction_advice": advice,
        "evidence_start_sec": evidence_ts,
        "evidence_end_sec": evidence_ts,
        "confidence": round(confidence, 3),
    }



def diagnose_serve(features: Dict, phase_marks: Dict, input_quality: Dict, serve_rules: List[Dict]) -> Dict:
    toss_score = 100.0
    loading_score = 100.0
    contact_score = 100.0
    balance_score = 100.0
    rhythm_score = 100.0

    problems: List[Dict] = []
    strengths: List[str] = []
    applied_rule_names: List[str] = [r.get("rule_name", "") for r in serve_rules]

    toss = features.get("toss", {})
    loading = features.get("loading", {})
    contact = features.get("contact", {})
    balance = features.get("balance", {})
    rhythm = features.get("rhythm", {})

    toss_ts = phase_marks.get("toss_release")
    trophy_ts = phase_marks.get("trophy_pose")
    impact_ts = phase_marks.get("impact_estimate")

    toss_height = toss.get("toss_hand_height_ratio")
    if toss_height is not None:
        if toss_height < 0.58:
            toss_score -= 20
            problems.append(_problem(
                "toss_too_low", "toss", "high",
                "抛球手上举高度明显不足，后续准备时间容易被压缩。",
                "先做无拍定点抛球，重点延长抛球手向上送球路径。",
                toss_ts, 0.70,
            ))
        elif toss_height < 0.72:
            toss_score -= 10
            problems.append(_problem(
                "toss_too_low", "toss", "medium",
                "抛球高度略低，容易造成发球节奏偏赶。",
                "练习抛球后短暂停顿，保证身体有完整上升准备。",
                toss_ts, 0.62,
            ))
        else:
            strengths.append("抛球手上举高度基本具备发球准备条件。")

    toss_offset = toss.get("toss_lateral_offset")
    if toss_offset is not None and toss_offset > 1.35:
        toss_score -= 10
        problems.append(_problem(
            "toss_lateral_offset_large", "toss", "medium",
            "抛球相对身体中线偏移较大，稳定性不足。",
            "先做站定抛球，尽量让抛球落在头顶略前的稳定区域。",
            toss_ts, 0.58,
        ))

    min_knee = loading.get("min_knee_angle")
    if min_knee is not None:
        if min_knee > 125:
            loading_score -= 18
            problems.append(_problem(
                "knee_bend_insufficient", "loading", "high",
                "蓄力阶段屈膝不足，下肢参与不够。",
                "做 trophy pose 停顿训练，感受下肢先蓄力再向上顶。",
                trophy_ts, 0.74,
            ))
        elif min_knee > 110:
            loading_score -= 10
            problems.append(_problem(
                "knee_bend_insufficient", "loading", "medium",
                "蓄力阶段屈膝略浅，向上发力空间有限。",
                "先固定起始站位，再练习屈膝-伸展的连续节奏。",
                trophy_ts, 0.66,
            ))
        else:
            strengths.append("蓄力阶段屈膝幅度基本到位。")

    shoulder_tilt = loading.get("shoulder_tilt")
    if shoulder_tilt is not None and shoulder_tilt < 6:
        loading_score -= 8
        problems.append(_problem(
            "shoulder_tilt_small", "loading", "low",
            "蓄力阶段肩线变化偏小，预备姿态不够完整。",
            "练习抛球后形成更清晰的 trophy pose，再进入上举加速。",
            trophy_ts, 0.55,
        ))

    impact_ext = contact.get("impact_arm_extension")
    if impact_ext is not None:
        if impact_ext < 0.72:
            contact_score -= 18
            problems.append(_problem(
                "impact_arm_extension_low", "contact", "high",
                "击球阶段手臂伸展不足，击球点和出手质量容易受影响。",
                "做无球挥拍，体会向上够球、向前送出的伸展感。",
                impact_ts, 0.71,
            ))
        elif impact_ext < 0.86:
            contact_score -= 10
            problems.append(_problem(
                "impact_arm_extension_low", "contact", "medium",
                "击球阶段手臂伸展还有提升空间。",
                "练习抛球后向上够球，避免击球前手臂提前收缩。",
                impact_ts, 0.63,
            ))
        else:
            strengths.append("击球阶段手臂伸展表现尚可。")

    impact_height = contact.get("impact_height_ratio")
    if impact_height is not None and impact_height < 0.95:
        contact_score -= 10
        problems.append(_problem(
            "impact_height_low", "contact", "medium",
            "击球点高度偏低，容易影响发球角度和力量输出。",
            "优先改善抛球与向上伸展的配合，争取更高的击球点。",
            impact_ts, 0.60,
        ))

    recovery = balance.get("recovery_score")
    if recovery is not None:
        if recovery < 0.35:
            balance_score -= 16
            problems.append(_problem(
                "balance_recovery_poor", "follow_through", "high",
                "随挥后的重心恢复较差，动作结束不够稳定。",
                "做发球后定住落地的练习，观察身体是否能自然前送并稳定停住。",
                phase_marks.get("follow_through_end"), 0.58,
            ))
        elif recovery < 0.55:
            balance_score -= 8
            problems.append(_problem(
                "balance_recovery_poor", "follow_through", "medium",
                "发球后重心恢复一般，还可以更稳定。",
                "做发球后停顿 1 秒的平衡训练，减少身体左右晃动。",
                phase_marks.get("follow_through_end"), 0.52,
            ))
        else:
            strengths.append("随挥后的身体恢复相对稳定。")

    toss_to_trophy = rhythm.get("toss_to_trophy_sec")
    trophy_to_impact = rhythm.get("trophy_to_impact_sec")
    if toss_to_trophy is not None and trophy_to_impact is not None:
        if toss_to_trophy < 0.10 or trophy_to_impact < 0.08:
            rhythm_score -= 12
            problems.append(_problem(
                "rhythm_too_rushed", "rhythm", "medium",
                "发球节奏偏赶，阶段之间衔接太快。",
                "先做慢节奏分解发球，把抛球、停顿、上举分开练。",
                trophy_ts, 0.54,
            ))
        else:
            strengths.append("动作阶段衔接没有明显过赶。")

    component_scores = {
        "toss_score": round(clamp(toss_score, 0.0, 100.0), 1),
        "loading_score": round(clamp(loading_score, 0.0, 100.0), 1),
        "contact_score": round(clamp(contact_score, 0.0, 100.0), 1),
        "balance_score": round(clamp(balance_score, 0.0, 100.0), 1),
        "rhythm_score": round(clamp(rhythm_score, 0.0, 100.0), 1),
    }

    total_score = round(
        (component_scores["toss_score"] * 0.25)
        + (component_scores["loading_score"] * 0.20)
        + (component_scores["contact_score"] * 0.25)
        + (component_scores["balance_score"] * 0.15)
        + (component_scores["rhythm_score"] * 0.15),
        1,
    )

    confidence_score = round(
        clamp(
            (input_quality.get("score", 0.0) * 0.55)
            + (phase_marks.get("phase_confidence", 0.0) * 0.25)
            + (0.20 if len(problems) + len(strengths) > 0 else 0.0),
            0.0,
            1.0,
        ),
        3,
    )

    level_band = (
        "5.0+" if total_score >= 90 else
        "4.0-4.5" if total_score >= 80 else
        "3.0-3.5" if total_score >= 68 else
        "2.0-2.5"
    )

    problems = sorted(
        problems,
        key=lambda p: {"high": 0, "medium": 1, "low": 2}.get(p["severity"], 3),
    )[:3]

    summary = "输入质量不足，结论仅供参考。" if input_quality.get("score", 0) < 0.45 else "本次分析可用于训练参考。"

    return {
        "total_score": total_score,
        "bucket": level_band,
        "confidence_score": confidence_score,
        "component_scores": component_scores,
        "problems": problems,
        "strengths": strengths[:3],
        "applied_rule_names": applied_rule_names,
        "summary_text": summary,
        "level_estimate": {
            "level_band": level_band,
            "confidence": confidence_score,
            "source": "score_proxy_v1",
        },
    }


# ---------- 5. 报告 ----------

def build_report(video_path: str, metadata: Dict, input_quality: Dict, phase_marks: Dict, features: Dict, diagnosis: Dict) -> Dict:
    analysis_status = "success" if input_quality.get("analyzable") else "low_quality"
    
    # 知识召回：根据问题召回教练知识点
    print("\n📚 召回教练知识点...")
    knowledge_recalls = []
    
    for problem in diagnosis.get("problems", []):
        phase = problem.get("phase_name", "")
        issue_desc = problem.get("description", "")
        
        # 根据问题描述召回相关知识点
        recalled = recall_knowledge_for_issues(phase, [issue_desc], limit=2)
        
        for item in recalled:
            knowledge_recalls.append({
                "coach": item.get("coach_name", "未知"),
                "title": item.get("title", ""),
                "summary": item.get("summary", ""),
                "type": item.get("knowledge_type", ""),
                "confidence": item.get("confidence", 0),
                "matched_problem": problem.get("problem_code", ""),
            })
    
    # 去重
    seen = set()
    unique_recalls = []
    for item in knowledge_recalls:
        key = f"{item['coach']}:{item['title']}"
        if key not in seen:
            seen.add(key)
            unique_recalls.append(item)
    
    print(f"✅ 召回了 {len(unique_recalls)} 条教练知识点")
    
    return {
        "video_path": video_path,
        "analysis_time": datetime.now().isoformat(),
        "mediapipe_version": mp.__version__,
        "analysis_status": analysis_status,
        "metadata": metadata,
        "input_quality": input_quality,
        "phase_marks": {
            k: v for k, v in phase_marks.items() if not k.startswith("_")
        },
        "features": features,
        "diagnosis": diagnosis,
        "knowledge_recall": {
            "total_recalled": len(unique_recalls),
            "coaches": list(set(item["coach"] for item in unique_recalls)),
            "items": unique_recalls[:5],  # 最多返回5条
        },
        # 向后兼容旧调用方：保留 evaluation 字段
        "evaluation": {
            "total_score": diagnosis["total_score"],
            "bucket": diagnosis["bucket"],
            "issues": diagnosis["problems"],
            "statistics": {
                "frames_analyzed": len(features) if isinstance(features, list) else None,
                "input_quality_score": input_quality.get("score"),
                "phase_confidence": phase_marks.get("phase_confidence"),
            },
        },
    }



def run_pipeline(video_path: str) -> Dict:
    serve_rules = load_serve_rules()
    extracted = extract_pose_sequence(video_path)
    metadata = extracted["metadata"]
    pose_frames = extracted["pose_frames"]

    input_quality = inspect_input(metadata, pose_frames)
    phase_marks = segment_serve_phases(pose_frames)
    features = extract_phase_features(pose_frames, phase_marks)
    diagnosis = diagnose_serve(features, phase_marks, input_quality, serve_rules)

    report = build_report(video_path, metadata, input_quality, phase_marks, features, diagnosis)
    return report



def main() -> None:
    if len(sys.argv) < 2:
        print("用法: python tennis_analyzer_mp11.py <视频路径>")
        sys.exit(1)

    video_path = sys.argv[1]
    print("=" * 60)
    print("🎾 网球发球分析系统 1.1")
    print(f"🧠 MediaPipe {mp.__version__} + 输入质量检查 + 阶段切分")
    print("=" * 60)

    try:
        report = run_pipeline(video_path)
        diagnosis = report["diagnosis"]

        print("\n" + "=" * 60)
        print("📊 分析报告")
        print("=" * 60)
        print(json.dumps(report, indent=2, ensure_ascii=False))
        print(f"\nFINAL_SCORE:{int(round(diagnosis['total_score']))}")
        print(f"BUCKET:{diagnosis['bucket']}")
        print(f"ISSUES_COUNT:{len(diagnosis['problems'])}")
        print(f"ANALYSIS_STATUS:{report['analysis_status']}")
    except Exception as exc:
        error_report = {
            "video_path": video_path,
            "analysis_time": datetime.now().isoformat(),
            "analysis_status": "failed",
            "error": str(exc),
        }
        print(json.dumps(error_report, indent=2, ensure_ascii=False))
        print("FINAL_SCORE:0")
        print("BUCKET:failed")
        print("ISSUES_COUNT:0")
        print("ANALYSIS_STATUS:failed")
        sys.exit(2)


if __name__ == "__main__":
    main()
