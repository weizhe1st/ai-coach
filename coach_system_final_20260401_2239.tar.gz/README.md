# 网球发球分析系统

基于 MediaPipe 0.10+ 和 AI 的网球发球动作分析系统，整合杨超教练知识库。

## 系统架构

```
微信上传视频 → COS存储 → MediaPipe分析 → 杨超知识库评估 → 报告生成
```

## 核心模块

### 1. 自动监控 (auto_monitor.js)
- 监控新视频上传
- 管理分析任务队列
- 协调报告投递

### 2. 视频分析 (tennis_analyzer_mp10.py)
- MediaPipe 0.10+ PoseLandmarker
- 姿态关键点检测
- 角度计算

### 3. 知识库评估
- 杨超教练知识库 (71条)
- 发球规则库 (5条)
- 智能评分系统

### 4. 消息推送
- 微信消息发送
- 飞书 API 支持

## 技术栈

- **后端**: Node.js, Python
- **AI**: MediaPipe 0.10+, TensorFlow Lite
- **数据库**: SQLite
- **存储**: 腾讯云 COS

## 目录结构

```
├── auto_monitor.js           # 自动监控系统
├── tennis_analyzer_mp10.py   # MediaPipe 分析
├── process_video_from_cos_v2.js  # COS 视频处理
├── feishu_api.js            # 飞书 API
├── wechat_sender.js         # 微信发送
├── feishu_callback_server.js # 飞书回调服务器
├── coach_knowledge/         # 杨超教练知识库
├── serve_rules/            # 发球规则
└── README.md
```

## 数据库表

- `coach_knowledge`: 杨超教练知识 (71条)
- `serve_rules`: 发球规则 (5条)
- `analysis_tasks`: 分析任务队列
- `clip_scoring_results`: 评分结果
- `clip_diagnosis_results`: 诊断结果

## 启动方式

```bash
# 启动自动监控
node auto_monitor.js start 60000

# 手动分析视频
python3 tennis_analyzer_mp10.py video.mp4
```

## 配置

复制 `.env.example` 到 `.env` 并填写：

```bash
COS_SECRET_ID=xxx
COS_SECRET_KEY=xxx
COS_BUCKET=xxx
COS_REGION=ap-shanghai
FEISHU_APP_ID=xxx
FEISHU_APP_SECRET=xxx
```

## 作者

- 系统开发: OpenClaw AI
- 知识库: 杨超教练

## License

Private
