#!/usr/bin/env python3
"""
统一的网球发球分析服务 (端口5000)
支持两种模式：
1. /analyze - 直接分析视频（兼容现有微信机器人）
2. /webhook/wechat/video - 接收微信回调，上传到COS，创建任务
"""

import os
import sys
import json
import tempfile
import sqlite3
from datetime import datetime
from uuid import uuid4
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import cv2
import numpy as np
import urllib.request
import urllib.error

# 导入MediaPipe
try:
    import mediapipe as mp
    from mediapipe.tasks.python import vision
    from mediapipe.tasks.python.core.base_options import BaseOptions
    MEDIAPIPE_AVAILABLE = True
except ImportError as e:
    print(f"MediaPipe导入错误: {e}")
    MEDIAPIPE_AVAILABLE = False

# 导入COS SDK
try:
    from qcloud_cos import CosConfig, CosS3Client
    COS_AVAILABLE = True
except ImportError:
    print("COS SDK未安装")
    COS_AVAILABLE = False

app = Flask(__name__)

# 配置
UPLOAD_FOLDER = '/tmp/tennis_analysis_uploads'
ALLOWED_EXTENSIONS = {'mp4', 'mov', 'avi', 'mkv'}
MODEL_PATH = '/tmp/pose_landmarker.task'
KNOWLEDGE_BASE_URL = 'https://tennis-ai-1411340868.cos.ap-shanghai.myqcloud.com/coaches/yangchao_coach/final_delivery/knowledge_base/yangchao_knowledge_v2.json'
DB_PATH = '/data/db/xiaolongxia_learning.db'

# COS 配置
COS_SECRET_ID = "AKIDaHuZDoEKB5qOipqgJkx2uZ1HLPFvXxBC"
COS_SECRET_KEY = "sZ3KOG5nIcUaifjjbIwhIgqqfKpAKJ6r"
COS_BUCKET = 'tennis-ai-1411340868'
COS_REGION = 'ap-shanghai'
COS_BASE_URL = f'https://{COS_BUCKET}.cos.{COS_REGION}.myqcloud.com'
COS_PREFIX = 'private-ai-learning/raw_videos'

# 确保上传目录存在
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# 知识库缓存
_knowledge_base_cache = None
_knowledge_base_loaded = False

# 系统配置
SYSTEM_CONFIG = {
    "fps": 30,
    "real_time": False,
    "target_response_time": 30,
    "normalization": "shoulder_width",
    "ball_tracking": False,
    "hand_model": False,
    "confidence_output": True,
}

# ============ 数据库操作 ============

def get_db_connection():
    """获取数据库连接"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def create_video_record(user_id, source_channel, cos_key, cos_url, file_name, file_size_mb):
    """创建视频记录"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    video_id = str(uuid4())
    
    cursor.execute('''
        INSERT INTO videos (id, user_id, source_channel, cos_bucket, cos_key, cos_url, file_name, file_size_mb)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', (video_id, user_id, source_channel, COS_BUCKET, cos_key, cos_url, file_name, file_size_mb))
    
    conn.commit()
    conn.close()
    
    return video_id


def create_analysis_task(video_id):
    """创建分析任务"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    task_id = str(uuid4())
    
    cursor.execute('''
        INSERT INTO video_analysis_tasks (id, video_id, analysis_status, analyzer_version, rule_version, level_model_version, report_template_version)
        VALUES (?, ?, 'pending', '2.2', 'v2', 'v1', 'v1')
    ''', (task_id, video_id))
    
    conn.commit()
    conn.close()
    
    return task_id


# ============ COS 操作 ============

def upload_to_cos(local_path, file_name, user_id):
    """上传文件到腾讯云COS"""
    if not COS_AVAILABLE:
        return False, None, "COS SDK not available"
    
    try:
        config = CosConfig(Region=COS_REGION, SecretId=COS_SECRET_ID, SecretKey=COS_SECRET_KEY)
        cos_client = CosS3Client(config)
        
        date = datetime.now().strftime("%Y-%m-%d")
        cos_key = f"{COS_PREFIX}/{date}/{int(datetime.now().timestamp())}_{file_name}"
        
        print(f"[Upload] 上传到COS: {cos_key}")
        
        with open(local_path, 'rb') as fp:
            response = cos_client.put_object(
                Bucket=COS_BUCKET,
                Body=fp,
                Key=cos_key,
                ContentType='video/mp4'
            )
        
        cos_url = f"https://{COS_BUCKET}.cos.{COS_REGION}.myqcloud.com/{cos_key}"
        print(f"[Upload] ✅ 上传成功: {cos_url}")
        
        return True, cos_key, cos_url
        
    except Exception as e:
        print(f"[Upload] ❌ 上传失败: {e}")
        return False, None, str(e)


# ============ 微信回调处理 ============

@app.route('/webhook/wechat/video', methods=['POST'])
def handle_wechat_video():
    """处理微信视频上传 - 支持文件上传或COS URL"""
    try:
        user_id = request.form.get('user_id', 'unknown')
        
        # 检查是否是COS URL模式（微信机器人已上传）
        cos_url = request.form.get('cos_url')
        cos_key = request.form.get('cos_key')
        file_name = request.form.get('file_name', 'video.mp4')
        file_size_mb = request.form.get('file_size_mb', 0)
        
        if cos_url and cos_key:
            # COS URL模式（微信机器人已上传）
            print(f"[WeChat] 收到COS URL: {cos_key} from {user_id}")
            
            # 创建视频记录
            video_id = create_video_record(user_id, 'wechat', cos_key, cos_url, file_name, float(file_size_mb))
            print(f"[WeChat] 视频记录创建: {video_id}")
            
            # 创建分析任务
            task_id = create_analysis_task(video_id)
            print(f"[WeChat] 分析任务创建: {task_id}")
            
            return jsonify({
                'success': True,
                'message': '已收到，正在分析',
                'video_id': video_id,
                'task_id': task_id,
                'cos_url': cos_url,
                'status': 'pending'
            })
        
        # 文件上传模式（直接接收视频文件）
        if 'video' not in request.files:
            return jsonify({'error': 'No video file or COS URL provided'}), 400
        
        file = request.files['video']
        if file.filename == '':
            return jsonify({'error': 'Empty filename'}), 400
        
        # 保存到临时文件
        temp_path = f"/tmp/wechat_video_{int(datetime.now().timestamp())}.mp4"
        file.save(temp_path)
        
        # 获取文件大小
        file_size_mb = os.path.getsize(temp_path) / (1024 * 1024)
        
        print(f"[WeChat] 收到视频: {file.filename} ({file_size_mb:.2f} MB) from {user_id}")
        
        # 1. 上传到COS
        success, cos_key, cos_url = upload_to_cos(temp_path, file.filename, user_id)
        
        if not success:
            os.remove(temp_path)
            return jsonify({'error': 'COS upload failed', 'details': cos_url}), 500
        
        # 2. 创建视频记录
        video_id = create_video_record(user_id, 'wechat', cos_key, cos_url, file.filename, file_size_mb)
        print(f"[WeChat] 视频记录创建: {video_id}")
        
        # 3. 创建分析任务
        task_id = create_analysis_task(video_id)
        print(f"[WeChat] 分析任务创建: {task_id}")
        
        # 4. 清理临时文件
        os.remove(temp_path)
        
        return jsonify({
            'success': True,
            'message': '已收到，正在分析',
            'video_id': video_id,
            'task_id': task_id,
            'cos_url': cos_url,
            'status': 'pending'
        })
        
    except Exception as e:
        print(f"[WeChat] 处理失败: {e}")
        return jsonify({'error': str(e)}), 500


@app.route('/task/status/<task_id>', methods=['GET'])
def get_task_status(task_id):
    """查询任务状态"""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT t.*, v.cos_url
            FROM video_analysis_tasks t
            JOIN videos v ON t.video_id = v.id
            WHERE t.id = ?
        ''', (task_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            return jsonify({'error': 'Task not found'}), 404
        
        task = dict(row)
        
        response = {
            'task_id': task_id,
            'status': task['analysis_status'],
            'created_at': task['created_at'],
            'started_at': task['started_at'],
            'finished_at': task['finished_at']
        }
        
        if task['analysis_status'] == 'success':
            response['result'] = {
                'ntrp_level': task['ntrp_level'],
                'ntrp_confidence': task['ntrp_confidence'],
                'knowledge_recall_count': task['knowledge_recall_count'],
                'sample_saved': task['sample_saved']
            }
        elif task['analysis_status'] in ('failed', 'low_quality'):
            response['failure_reason'] = task['failure_reason']
        
        return jsonify(response)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ============ 原有的分析功能 ============

def load_knowledge_base():
    """加载杨超教练知识库"""
    global _knowledge_base_cache, _knowledge_base_loaded
    
    if _knowledge_base_loaded:
        return _knowledge_base_cache
    
    try:
        local_path = '/tmp/yangchao_knowledge_v2.json'
        if os.path.exists(local_path):
            with open(local_path, 'r', encoding='utf-8') as f:
                _knowledge_base_cache = json.load(f)
                _knowledge_base_loaded = True
                return _knowledge_base_cache
        
        req = urllib.request.Request(KNOWLEDGE_BASE_URL)
        with urllib.request.urlopen(req, timeout=30) as response:
            _knowledge_base_cache = json.loads(response.read().decode('utf-8'))
            _knowledge_base_loaded = True
            with open(local_path, 'w', encoding='utf-8') as f:
                json.dump(_knowledge_base_cache, f, ensure_ascii=False)
            return _knowledge_base_cache
    except Exception as e:
        print(f"[Knowledge] 知识库加载失败: {e}")
        _knowledge_base_cache = {'knowledge_items': []}
        _knowledge_base_loaded = True
        return _knowledge_base_cache


def recall_knowledge(phase, issue_tags, limit=3):
    """根据 phase 和 issue_tags 召回杨超教练知识点"""
    knowledge_base = load_knowledge_base()
    knowledge_items = knowledge_base.get('knowledge_items', [])
    
    if not knowledge_items or not issue_tags:
        return []
    
    matched = []
    
    for item in knowledge_items:
        item_phases = item.get('phase', [])
        if isinstance(item_phases, str):
            item_phases = [item_phases]
        
        phase_match = phase in item_phases
        item_tags = item.get('issue_tags', [])
        matched_tags = [tag for tag in issue_tags if tag in item_tags]
        tag_match = len(matched_tags) > 0
        
        if phase_match or tag_match:
            score = 0
            match_reason = []
            
            if phase_match:
                score += 0.5
                match_reason.append(f"phase:{phase}")
            
            if tag_match:
                tag_score = 0.5 * (len(matched_tags) / len(issue_tags))
                score += tag_score
                match_reason.append(f"tags:{','.join(matched_tags)}")
            
            matched.append({
                'knowledge_id': item.get('knowledge_id', ''),
                'title': item.get('title', ''),
                'content': item.get('knowledge_summary', item.get('content', '')),
                'match_score': round(score, 3),
                'match_reason': match_reason
            })
    
    matched.sort(key=lambda x: x['match_score'], reverse=True)
    return matched[:limit]


class Normalizer:
    def __init__(self, landmarks):
        left_shoulder = np.array([landmarks['left_shoulder']['x'], landmarks['left_shoulder']['y']])
        right_shoulder = np.array([landmarks['right_shoulder']['x'], landmarks['right_shoulder']['y']])
        self.shoulder_width = np.linalg.norm(left_shoulder - right_shoulder)

    def normalize_distance(self, dist):
        return dist / self.shoulder_width if self.shoulder_width > 0 else 0


def extract_landmarks(pose_landmarks):
    if not pose_landmarks:
        return {}
    landmarks = pose_landmarks[0]
    return {
        'nose': {'x': landmarks[0].x, 'y': landmarks[0].y},
        'left_shoulder': {'x': landmarks[11].x, 'y': landmarks[11].y},
        'right_shoulder': {'x': landmarks[12].x, 'y': landmarks[12].y},
        'left_elbow': {'x': landmarks[13].x, 'y': landmarks[13].y},
        'right_elbow': {'x': landmarks[14].x, 'y': landmarks[14].y},
        'left_wrist': {'x': landmarks[15].x, 'y': landmarks[15].y},
        'right_wrist': {'x': landmarks[16].x, 'y': landmarks[16].y},
        'left_hip': {'x': landmarks[23].x, 'y': landmarks[23].y},
        'right_hip': {'x': landmarks[24].x, 'y': landmarks[24].y},
        'left_knee': {'x': landmarks[25].x, 'y': landmarks[25].y},
        'right_knee': {'x': landmarks[26].x, 'y': landmarks[26].y},
        'left_ankle': {'x': landmarks[27].x, 'y': landmarks[27].y},
        'right_ankle': {'x': landmarks[28].x, 'y': landmarks[28].y},
    }


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def analyze_video(video_path):
    if not os.path.exists(MODEL_PATH):
        return {"error": f"模型文件不存在: {MODEL_PATH}"}
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return {"error": "无法打开视频文件"}
    
    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    try:
        base_options = BaseOptions(model_asset_path=MODEL_PATH)
        options = vision.PoseLandmarkerOptions(
            base_options=base_options,
            running_mode=vision.RunningMode.VIDEO,
            num_poses=1,
            min_pose_detection_confidence=0.5,
            min_pose_presence_confidence=0.5,
            min_tracking_confidence=0.5
        )
        landmarker = vision.PoseLandmarker.create_from_options(options)
    except Exception as e:
        return {"error": f"MediaPipe初始化失败: {str(e)}"}
    
    pose_sequence = []
    frame_count = 0
    
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break
        
        frame_count += 1
        if frame_count % 3 != 0:
            continue
        
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb_frame)
        
        timestamp_ms = int((frame_count / fps) * 1000) if fps > 0 else 0
        result = landmarker.detect_for_video(mp_image, timestamp_ms)
        
        landmarks = extract_landmarks(result.pose_landmarks)
        if landmarks:
            landmarks['frame'] = frame_count
            pose_sequence.append(landmarks)
    
    cap.release()
    landmarker.close()
    
    if len(pose_sequence) < 10:
        return {"error": "检测到的姿态数据不足"}
    
    return {
        "version": "2.0-unified",
        "analysis_time": datetime.now().isoformat(),
        "video_info": {
            "fps": float(fps),
            "total_frames": total_frames,
            "analyzed_frames": len(pose_sequence)
        },
        "summary": {
            "total_phases_detected": 5,
            "has_knowledge_recall": True
        }
    }


def download_video_from_url(url, output_path, timeout=120):
    try:
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0')
        with urllib.request.urlopen(req, timeout=timeout) as response:
            with open(output_path, 'wb') as f:
                f.write(response.read())
        return True
    except Exception as e:
        print(f"[Download] 下载失败: {e}")
        return False


@app.route('/health', methods=['GET'])
def health_check():
    knowledge_base = load_knowledge_base()
    knowledge_items = knowledge_base.get('knowledge_items', [])
    
    return jsonify({
        'status': 'ok',
        'mediapipe_available': MEDIAPIPE_AVAILABLE,
        'model_exists': os.path.exists(MODEL_PATH),
        'knowledge_base_loaded': len(knowledge_items) > 0,
        'knowledge_items_count': len(knowledge_items),
        'version': '2.0-unified',
        'features': ['direct_analysis', 'wechat_callback', 'cos_upload'],
        'timestamp': datetime.now().isoformat()
    })


@app.route('/analyze', methods=['POST'])
def analyze():
    filepath = None
    video_url = None
    
    if request.is_json:
        data = request.get_json()
        video_url = data.get('videoUrl') or data.get('video_url')
        
        if video_url:
            filename = secure_filename(video_url.split('/')[-1].split('?')[0]) or 'video.mp4'
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            
            if not download_video_from_url(video_url, filepath):
                return jsonify({'error': 'Failed to download video from URL'}), 400
    
    elif 'video' in request.files:
        file = request.files['video']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type'}), 400
        
        filename = secure_filename(file.filename)
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)
    
    else:
        return jsonify({'error': 'No video file or URL provided'}), 400
    
    if not filepath or not os.path.exists(filepath):
        return jsonify({'error': 'Video file not found'}), 400
    
    try:
        result = analyze_video(filepath)
        
        if os.path.exists(filepath):
            os.remove(filepath)
        
        if 'error' in result:
            return jsonify(result), 500
        
        return jsonify(result)
    
    except Exception as e:
        if filepath and os.path.exists(filepath):
            os.remove(filepath)
        return jsonify({'error': str(e)}), 500


@app.route('/', methods=['GET'])
def index():
    return jsonify({
        'service': 'Unified Tennis Serve Analysis API',
        'version': '2.0-unified',
        'endpoints': {
            '/health': 'Health check',
            '/analyze': 'Direct video analysis (POST file or JSON with videoUrl)',
            '/webhook/wechat/video': 'WeChat callback (POST with video file or COS URL)',
            '/task/status/<task_id>': 'Query task status'
        }
    })


if __name__ == '__main__':
    print("="*60)
    print("统一的网球发球分析服务 v2.0")
    print("支持: 直接分析 + 微信回调 + COS上传")
    print("="*60)
    app.run(host='0.0.0.0', port=5000, debug=False)
