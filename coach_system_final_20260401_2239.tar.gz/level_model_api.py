#!/usr/bin/env python3
"""
等级模型 API 服务
提供等级评估、人工修正、样本评级、相似样本检索接口
"""

import os
import sys
import json
from flask import Flask, request, jsonify
from level_model_service import level_service

app = Flask(__name__)


@app.route('/level/evaluate', methods=['POST'])
def evaluate_level():
    """评估等级"""
    try:
        data = request.get_json()
        features = data.get('features', {})
        
        if not features:
            return jsonify({'error': 'No features provided'}), 400
        
        result = level_service.evaluate_level(features)
        return jsonify(result)
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/correction', methods=['POST'])
def add_correction():
    """添加人工修正"""
    try:
        data = request.get_json()
        
        task_id = data.get('task_id')
        video_id = data.get('video_id')
        original_level = data.get('original_level')
        corrected_level = data.get('corrected_level')
        corrected_by = data.get('corrected_by', 'admin')
        reason = data.get('reason', '')
        
        if not all([task_id, video_id, corrected_level]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        correction_id = level_service.add_manual_correction(
            task_id, video_id, original_level, corrected_level, 
            corrected_by, reason
        )
        
        return jsonify({
            'success': True,
            'correction_id': correction_id,
            'message': f'Level corrected from {original_level} to {corrected_level}'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/training/rate', methods=['POST'])
def rate_sample():
    """评级训练样本"""
    try:
        data = request.get_json()
        
        task_id = data.get('task_id')
        video_id = data.get('video_id')
        sample_quality = data.get('sample_quality')  # excellent/good/fair/poor
        rated_by = data.get('rated_by', 'admin')
        notes = data.get('notes', '')
        tags = data.get('tags', [])
        
        if not all([task_id, video_id, sample_quality]):
            return jsonify({'error': 'Missing required fields'}), 400
        
        if sample_quality not in ('excellent', 'good', 'fair', 'poor'):
            return jsonify({'error': 'Invalid sample_quality'}), 400
        
        sample_id = level_service.rate_training_sample(
            task_id, video_id, sample_quality, rated_by, notes, tags
        )
        
        return jsonify({
            'success': True,
            'sample_id': sample_id,
            'message': f'Sample rated as {sample_quality}'
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/similar', methods=['POST'])
def find_similar():
    """查找相似样本"""
    try:
        data = request.get_json()
        
        features = data.get('features', {})
        ntrp_level = data.get('ntrp_level')  # optional
        limit = data.get('limit', 5)
        
        if not features:
            return jsonify({'error': 'No features provided'}), 400
        
        results = level_service.find_similar_samples(features, ntrp_level, limit)
        
        return jsonify({
            'count': len(results),
            'samples': results
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/stats/corrections', methods=['GET'])
def get_correction_stats():
    """获取人工修正统计"""
    try:
        stats = level_service.get_correction_stats()
        return jsonify({'corrections': stats})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/stats/training', methods=['GET'])
def get_training_stats():
    """获取训练样本统计"""
    try:
        stats = level_service.get_training_sample_stats()
        return jsonify({'training_samples': stats})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({
        'status': 'ok',
        'service': 'level-model-api',
        'version': '2.0'
    })


@app.route('/', methods=['GET'])
def index():
    """首页"""
    return jsonify({
        'service': 'Level Model API Service',
        'version': '2.0',
        'features': [
            'NTRP Level Evaluation (2.0-5.0+)',
            'Manual Correction Loop',
            'Training Sample Rating',
            'Similar Sample Retrieval'
        ],
        'endpoints': {
            '/level/evaluate': 'POST - Evaluate level from features',
            '/correction': 'POST - Add manual correction',
            '/training/rate': 'POST - Rate training sample',
            '/similar': 'POST - Find similar samples',
            '/stats/corrections': 'GET - Correction statistics',
            '/stats/training': 'GET - Training sample statistics'
        }
    })


if __name__ == '__main__':
    print("="*60)
    print("等级模型 API 服务 v2.0")
    print("="*60)
    app.run(host='0.0.0.0', port=5002, debug=False)
